<div ng-controller="View1Ctrl">

<nav class="navbar" ng-class="class" >
  <ul>
    <li><a class="anchor" href="webpages/aboutme/aboutme.php">About</a></li>
    <li><a class="anchor" href="projects.html">Projects</a></li>
    <li><a class="anchor" href="contact.html">Contact</a></li>
    
 
   <img class='author' src="view1/krfooter.jpg" alt="author" height="100px" width="100px" class="img-responsive" data-toggle="tooltip" data-placement="top" title="Tooltip on top" > 

  </ul>
</nav>

<div class="fullscreen-bg vid-container">
    <video class="bgvid fullscreen-bg__video" autoplay="autoplay" muted="muted" preload="auto" loop>
      <source src="http://mazwai.com/system/posts/videos/000/000/109/webm/leif_eliasson--glaciartopp.webm?1410742112" type="video/webm">
  </video>
 <!-- <span class="site-nav-logo glyphicon glyphicon-arrow-up">
      </span>-->
  <div class="title" id='slider'><span>Karan Rawat</span><span>Electronics Engineer , Web Designer and<a>Web Developer</a></span></div>
 
  <!--<div class="container">-->
  <div class="ghost">
  <h3 class="ghost-btn" ng-click="navbar()">HELLO,THERE</h3>
  </div>

  


   </div>
 </div>


 	

